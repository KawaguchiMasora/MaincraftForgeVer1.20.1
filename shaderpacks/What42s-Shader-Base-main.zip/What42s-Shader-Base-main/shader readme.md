## Thank you for using my shader!

Please keep in mind that this is a very work-in-progress shader, and there's a lot of room for improvement. I'm not sure how this will go, but I'm sure I'll adapt to whatever comes up. If you need to contact me, my Discord name is What42Pizza.

<br>

- **[Repository](https://github.com/What42Pizza/What42s-Shader-Base)** &nbsp; (includes (probably bad) documentation)
- **[Official Download](https://modrinth.com/shader/what42s-shader-base)** &nbsp; (Modrinth)
- **[Official Download](https://legacy.curseforge.com/minecraft/shaders/what42s-shader-base)** &nbsp; (CurseForge)
- **[License](LICENSE)**
