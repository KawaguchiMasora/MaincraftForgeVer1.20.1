to use rust-utils:

1: make sure you can run Rust programs
2: navigate to rust-utils
3: run 'cargo run -- help'



======== WARNING ========

There seems to be a bug in the zip crate that makes the exports unusable by default. To fix this, you'll need to unzip then re-zip the contents manually before uploading
