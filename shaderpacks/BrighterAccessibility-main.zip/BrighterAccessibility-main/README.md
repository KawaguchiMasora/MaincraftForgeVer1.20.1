# BrighterAccessibility
Removes the shadows from the game for people with visually impaired people. Has Distant Horizons support.
